package a;

public class One {
	private String first = "first";
	String second = "second";
	protected String third = "third";
	public String fourth = "fourth";
	
	public void print(){
		System.out.println(first);
		System.out.println(second);
		System.out.println(third);
		System.out.println(fourth);
	}
}
class Two {
	public void print(){
		One one = new One();
//		System.out.println(one.first);
		System.out.println(one.second);
		System.out.println(one.third);
		System.out.println(one.fourth);
	}
}
class Three extends One{
	public void print(String s){
//		System.out.println(first);
		System.out.println(second);
		System.out.println(third);
		System.out.println(fourth);
	}
}