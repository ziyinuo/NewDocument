import java.util.Scanner;

public class DateTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner test = new Scanner("t");
		System.out.println(test);
	}

}
