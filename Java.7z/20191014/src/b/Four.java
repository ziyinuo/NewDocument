package b;

import a.One;

public class Four {
	public void print(){
		One one = new One();
//		System.out.println(one.first);
//		System.out.println(one.second);
//		System.out.println(one.third);
		System.out.println(one.fourth);
	}
}

class Five extends One{
	public void print(String s){
//		System.out.println(first);
//		System.out.println(second);
		System.out.println(third);
		System.out.println(fourth);
	}
}