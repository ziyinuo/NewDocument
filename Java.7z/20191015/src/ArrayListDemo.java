import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList list1 = new ArrayList();
		list1.add(123);//int-->Integer-->Object
		list1.add("abc");
		list1.add(true);
		list1.add(new java.util.Date());
		list1.add(null);
		list1.add("abc");
		list1.add(null);
		list1.add(3, '��');
		System.out.println(list1);
		
		for(int i=0 ; i<list1.size() ; i++){
			System.out.println(list1.get(i));
		}
		System.out.println("===================================");
		Iterator ite = list1.iterator();
		while(ite.hasNext()){
			System.out.println(ite.next());
		}
		System.out.println("===================================");
		for(Object element : list1){
			System.out.println(element);
		}
	}
}