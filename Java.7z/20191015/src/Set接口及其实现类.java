import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Set�ӿڼ���ʵ���� {

	public static void main(String[] args) {
		HashSet<String> set1 = new HashSet<String>();
		Set<Object> set2 = new HashSet<Object>();
		set1.add("abc");
		set1.add("123");
		set1.add("456");
		set1.add("def");
		set1.add("123");
		set1.add(null);
		set1.add(null);
//		System.out.println(set1.size());
//		System.out.println(set1);
		/*for(int i=0 ; i<set1.size() ; i++){
			System.out.println(set1.get(i));
		}*/
//		for(String s : set1){
//			System.out.println(s);
//		}
//		Iterator<String> ite = set1.iterator();
//		while(ite.hasNext()){
//			System.out.println(ite.next());
//		}
		
		HashSet<Employee> set3 = new HashSet<Employee>();
		Employee emp1 = new Employee("����",27);
		Employee emp2 = new Employee("����",26);
		Employee emp3 = new Employee("����",27);
		Employee emp4 = emp1;
		set3.add(emp1);
		set3.add(emp2);
		set3.add(emp3);
		set3.add(emp4);
		System.out.println(set3.size());
		System.out.println(set3);
	}
}
//ʹ�����е�equals()������hashCode()���Ƚ϶��������ԡ�
//����ͬʱ��дequals()������hashCode()��HashSet����׼ȷ�жϳ����������Ƿ���ȡ�
//��������ʱ��Ҫ��дequals()���������ܱȽ�����ԣ��Ƴ��ظ�������
class Employee{
	private String name;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + "]";
	}
//	@Override
//	public int hashCode() {
//		final int prime = 31;
//		int result = 1;
//		result = prime * result + age;
//		result = prime * result + ((name == null) ? 0 : name.hashCode());
//		return result;
//	}
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Employee other = (Employee) obj;
//		if (age != other.age)
//			return false;
//		if (name == null) {
//			if (other.name != null)
//				return false;
//		} else if (!name.equals(other.name))
//			return false;
//		return true;
//	}
}