import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ���ڸ�ʽ�� {
	public static void main(String[] args) throws ParseException {
		Date today = new Date();
		DateFormat df1 = DateFormat.getDateInstance();
		DateFormat df2 = DateFormat.getDateInstance(DateFormat.SHORT);
		DateFormat df3 = DateFormat.getDateInstance(DateFormat.MEDIUM);
		DateFormat df4 = DateFormat.getDateInstance(DateFormat.LONG);
		DateFormat df5 = DateFormat.getDateInstance(DateFormat.FULL);
		
		System.out.println(df1.format(today));
		System.out.println(df2.format(today));
		System.out.println(df3.format(today));
		System.out.println(df4.format(today));
		System.out.println(df5.format(today));
		
		String str = "2008��08��08��";
		Date mydate = df4.parse(str);
		System.out.println(mydate);
		
		DateFormat df6 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(df6.format(today));
	}

}
