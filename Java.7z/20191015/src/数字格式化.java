import java.text.NumberFormat;
import java.text.ParseException;

public class ���ָ�ʽ�� {

	public static void main(String[] args) throws ParseException {
		NumberFormat nf1 = NumberFormat.getNumberInstance();
		NumberFormat nf2 = NumberFormat.getCurrencyInstance();
		NumberFormat nf3 = NumberFormat.getPercentInstance();
		System.out.println(nf1.format(1234567.123456));
		System.out.println(nf2.format(1234567.123456));
		System.out.println(nf3.format(1234567.123456));
		
		String str = "��1,234,567.12";
		double dou = nf2.parse(str).doubleValue();
		Double dou2 = (Double)nf2.parse(str);
		System.out.println(dou);
		System.out.println(dou2);
	}

}
