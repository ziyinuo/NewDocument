import java.util.Locale;

public class LocaleDemo {
	public static void main(String[] args) {
		Locale l1 = Locale.CHINA;
		Locale l2 = Locale.CHINESE;
		Locale l3 = new Locale("zh");
		Locale l4 = new Locale("zh", "CN");
		System.out.println(l1);
		System.out.println(l2);
		System.out.println(l3);
		System.out.println(l4);
	}
}