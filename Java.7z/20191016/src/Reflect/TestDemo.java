package Reflect;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;

@SuppressWarnings(value="unchecked")
public class TestDemo {

	private TestDemo(){}
	public TestDemo(int i){
		System.out.println("������������");
	}
	public void info(){
		System.out.println("�޲η���");
	} 
	public void info(int i){
		System.out.println("�вη���");
	}
	class InClass{}
	
	public static void main(String[] args) throws Exception {
		Class<TestDemo> clazz = TestDemo.class;
		Constructor[] ctors = clazz.getDeclaredConstructors();
//		System.out.println("TestDemo�Ĺ�����");
//		for(Constructor c : ctors){
//			System.out.println(c);
//		}
//		System.out.println("public������");
//		Constructor[] pctors = clazz.getConstructors();
//		for(Constructor c : pctors){
//			System.out.println(c);
//		}
//		Method[] methods = clazz.getMethods();
//		for(Method m:methods){
//			System.out.println(m);
//		}
//		System.out.println(clazz.getMethod("info"));
//		Annotation[] anns = clazz.getAnnotations();
//		for (Annotation a : anns){
//			System.out.println(a);
//		}
//		System.out.println(clazz.getAnnotation(SuppressWarnings.class));
//		Class<?>[] in = clazz.getDeclaredClasses();
//		for(Class i : in) {
//			System.out.println(i);
//		}
	
		Class inClazz = Class.forName("TestDemo$InClass");
		System.out.println(inClazz.getDeclaringClass());
		System.out.println(inClazz.getPackage());
		System.out.println(inClazz.getSuperclass());
	
	}

}
